"""Gradio app for head-to-head leaderboard comparisons of two participants."""

import gradio as gr
import pandas as pd
import plotly.graph_objects as go
from config import ACTIVITY_ENDPOINTS, MACRO_ENDPOINT_LABEL, S3_BUCKET
from loguru import logger
from utils import _load_csv_from_s3

MANIFEST_URI = "leaderboard/final/{track}/manifest.csv"
LEADERBOARD_URI = "leaderboard/final/{track}/leaderboard_latest.csv"
PAIRWISE_URI = "leaderboard/final/{track}/pairwise_comparisons.csv"
DATASET_URI = "ground_truth/activity-dataset.parquet"
IDENTIFIERS_URI = "ground_truth/{track}-identifiers.parquet"

# Track-specific primary metric and sort direction. Activity now scores 8 endpoints
# (see ACTIVITY_ENDPOINTS in config.py); this comparison only ever uses the
# multi-endpoint macro-averaged primary metric (RAE), matching backend's leaderboard
# ranking/CLD metric — see MACRO_ENDPOINT_LABEL handling in _load_bootstrap below.
TRACK_PRIMARY_METRIC = {"activity": "RAE", "structure": "LDDT-PLI"}
LOWER_IS_BETTER = ["RAE"]
ALPHA_LEVEL = 0.05
ACTIVITY_TARGET_PHASE = 2  # Phase-2 compounds used for activity scatter
# One scatter tab per activity endpoint.

# Colour palette
COLOR_USER_A = "#4C72B0"
COLOR_USER_B = "#DD8452"
COLOR_GT = "#55A868"
COLOR_POS_DELTA = "#4C72B0"
COLOR_NEG_DELTA = "#DD8452"

# ==============================================================================
# 1. GLOBAL INITIALIZATION (Runs once, the first time render_comparisons() is
# called — i.e. only when the Head-to-head tab is actually rendered)
# ==============================================================================

DATA_CACHE: dict[str, pd.DataFrame] = {}


def download_necessary_files() -> dict[str, pd.DataFrame]:
    """Load all necessary files for the head-to-head comparison globally on bootup."""
    logger.info("⚡ Initializing global data fetch from S3...")
    files = {}
    for track in ["activity", "structure"]:
        manifest_key = MANIFEST_URI.format(track=track)
        leaderboard_key = LEADERBOARD_URI.format(track=track)
        pairwise_key = PAIRWISE_URI.format(track=track)
        identifiers_key = IDENTIFIERS_URI.format(track=track)

        try:
            files[f"{track}_manifest"] = _load_csv_from_s3(manifest_key)
            files[f"{track}_leaderboard"] = _load_csv_from_s3(leaderboard_key)
            files[f"{track}_pairwise"] = _load_csv_from_s3(pairwise_key)
            files[f"{track}_identifiers"] = _load_csv_from_s3(
                identifiers_key, parquet=True
            )
        except Exception as e:
            logger.error(
                f"Critical error pre-loading S3 files for track '{track}': {e}"
            )
    try:
        files["activity_dataset"] = _load_csv_from_s3(DATASET_URI, parquet=True)
    except Exception as e:
        logger.error(f"Critical error pre-loading activity dataset from S3: {e}")
    return files


# ==============================================================================
# 2. IN-MEMORY UTILITY FUNCTIONS
# ==============================================================================


def list_leaderboard_entries(track: str) -> list[str]:
    """List all leaderboard entries instantly from the in-memory global cache."""
    if not track:
        return []

    track = track.lower()
    cache_key = f"{track}_leaderboard"

    if cache_key not in DATA_CACHE:
        logger.error(f"Track cache key '{cache_key}' not found.")
        return []

    try:
        leaderboard_df = DATA_CACHE[cache_key]
        leaderboard_df["display_username"] = leaderboard_df.apply(
            lambda row: row["user_alias"] if row["anonymous"] else row["username"],
            axis=1,
        )
        entries = [
            f"{rank + 1}. {entry}"
            for rank, entry in enumerate(
                leaderboard_df["display_username"].dropna().tolist()
            )
        ]
        return entries
    except Exception as e:
        logger.error(f"Error parsing in-memory leaderboard for track '{track}': {e}")
        return []


def convert_rank_to_path(track: str, rank: int) -> str:
    """Convert a leaderboard rank to the corresponding S3 all-compound scores URI."""
    track = track.lower()
    leaderboard = DATA_CACHE[f"{track}_leaderboard"]
    hf_username = leaderboard.loc[rank, "username"]
    manifest = DATA_CACHE[f"{track}_manifest"]
    scores_uri = manifest[manifest["username"] == hf_username].all_scores_uri.values[0]
    return scores_uri


def _get_display_name(track: str, rank: int) -> str:
    """Get the display name (alias if anonymous) for a user by leaderboard rank."""
    leaderboard = DATA_CACHE[f"{track.lower()}_leaderboard"]
    row = leaderboard.loc[rank]
    if bool(row.get("anonymous", False)) and row.get("user_alias"):
        return str(row["user_alias"])
    return str(row["username"])


def _get_hf_username(track: str, rank: int) -> str:
    """Get the actual HF username (for S3 paths and pairwise lookup) by rank."""
    leaderboard = DATA_CACHE[f"{track.lower()}_leaderboard"]
    return str(leaderboard.loc[rank, "username"])


def _get_pairwise_row(
    track: str, hf_username_a: str, hf_username_b: str
) -> pd.Series | None:
    """Look up the pairwise comparison row for two users (order-independent)."""
    pairwise = DATA_CACHE.get(f"{track.lower()}_pairwise")
    if pairwise is None or pairwise.empty:
        return None
    mask = (
        (pairwise["entry_a"] == hf_username_a) & (pairwise["entry_b"] == hf_username_b)
    ) | (
        (pairwise["entry_a"] == hf_username_b) & (pairwise["entry_b"] == hf_username_a)
    )
    hits = pairwise[mask]
    return hits.iloc[0] if not hits.empty else None


def _extract_username_and_submission_id(all_scores_uri: str) -> tuple[str, str]:
    """Extract username and submission_id from an S3 all_scores_uri.

    URI format: s3://{bucket}/scores/all/{track}/{username}/{submission_id}/averaged-results.parquet
    """
    path = all_scores_uri.replace(f"s3://{S3_BUCKET}/", "")
    parts = path.split("/")
    return parts[-3], parts[-2]


# ==============================================================================
# 3. DATA LOADING FOR COMPARISON
# ==============================================================================


def _load_activity_predictions(rank: int) -> pd.DataFrame:
    """Load activity predictions CSV for a user from S3."""
    uri = convert_rank_to_path("activity", rank)
    username, submission_id = _extract_username_and_submission_id(uri)
    key = f"submissions/activity/{username}/{submission_id}/predictions.csv"
    return _load_csv_from_s3(key, parquet=False)


def _load_structure_per_compound(rank: int) -> pd.DataFrame:
    """Load the per-compound structure scores for a user from S3."""
    uri = convert_rank_to_path("structure", rank)
    path = uri.replace(f"s3://{S3_BUCKET}/", "")
    key = path.replace("averaged-results.parquet", "per-compound-results.parquet")
    return _load_csv_from_s3(key, parquet=True)


def _load_bootstrap(track: str, rank: int) -> pd.DataFrame:
    """Load bootstrap-results.parquet for a user by leaderboard rank.

    Activity bootstrap files hold one row per (Sample, Endpoint) pair, including the
    "MA" pseudo-endpoint holding the multi-endpoint macro-averaged scores for that
    sample (see MACRO_ENDPOINT_LABEL). This comparison only ever uses the macro series
    — narrow down to it here so downstream code sees exactly one row per Sample.
    """
    key = (
        convert_rank_to_path(track, rank)
        .replace(f"s3://{S3_BUCKET}/", "")
        .replace("averaged-results.parquet", "bootstrap-results.parquet")
    )
    bootstrap_df = _load_csv_from_s3(key, parquet=True)
    if track.lower() == "activity":
        bootstrap_df = bootstrap_df[
            bootstrap_df["Endpoint"] == MACRO_ENDPOINT_LABEL
        ].drop(columns=["Endpoint"])
    return bootstrap_df


# ==============================================================================
# 4. CHART BUILDERS
# ==============================================================================


def build_stats_table(
    track: str,
    display_name_a: str,
    display_name_b: str,
    boot_a: pd.DataFrame,
    boot_b: pd.DataFrame,
    pw_row: pd.Series | None,
) -> str:
    """Build the HTML statistical summary table."""
    metric = TRACK_PRIMARY_METRIC.get(track.lower(), "MAE")

    mean_a = float(boot_a[metric].mean())
    std_a = float(boot_a[metric].std())
    mean_b = float(boot_b[metric].mean())
    std_b = float(boot_b[metric].std())

    if pw_row is not None:
        bh_rank = pw_row.get("adjustment_rank", "N/A")
        bh_threshold = pw_row.get("adjusted_threshold", "N/A")
        p_val = pw_row.get("p_value", "N/A")
        is_sig_raw = pw_row.get("significant_difference", None)
        if isinstance(bh_threshold, float):
            bh_threshold = f"{bh_threshold:.4f}"
        p_val_str = f"{p_val:.4f}" if isinstance(p_val, float) else str(p_val)
        # CSV booleans are read back as strings "True"/"False" or as numpy.bool_;
        # convert explicitly to Python bool so equality checks work reliably.
        if is_sig_raw is None:
            is_sig = None
        elif isinstance(is_sig_raw, str):
            is_sig = is_sig_raw.strip().lower() == "true"
        else:
            try:
                is_sig = bool(is_sig_raw) if not pd.isna(is_sig_raw) else None
            except (TypeError, ValueError):
                is_sig = None
    else:
        bh_rank = bh_threshold = "N/A"
        p_val_str = "N/A"
        is_sig = None

    if is_sig is True:
        sig_text, sig_color, sig_bg = "TRUE", "#1b5e20", "#e8f5e9"
    elif is_sig is False:
        sig_text, sig_color, sig_bg = "FALSE", "#b71c1c", "#ffebee"
    else:
        sig_text, sig_color, sig_bg = "N/A", "#555", "#f5f5f5"

    rows = [
        ("Track", track),
        ("User A", f"<strong>{display_name_a}</strong>"),
        ("User B", f"<strong>{display_name_b}</strong>"),
        ("Evaluation Metric", metric),
        (f"User A mean {metric} ± SD", f"{mean_a:.4f} ± {std_a:.4f}"),
        (f"User B mean {metric} ± SD", f"{mean_b:.4f} ± {std_b:.4f}"),
        ("Target FDR (Q)", str(ALPHA_LEVEL)),
        ("BH Rank (k)", str(bh_rank)),
        ("BH Critical Value", str(bh_threshold)),
        ("Observed p-value", p_val_str),
        (
            "Statistically Significant",
            f'<span style="font-weight:800;font-size:15px;color:{sig_color};'
            f'background:{sig_bg};padding:2px 10px;border-radius:4px">{sig_text}</span>',
        ),
    ]

    trs = "\n".join(
        f"<tr>"
        f'<td style="padding:8px 14px;font-weight:600;color:#555;'
        f'border-bottom:1px solid #e0e0e0;white-space:nowrap">{label}</td>'
        f'<td style="padding:8px 14px;border-bottom:1px solid #e0e0e0">{val}</td>'
        f"</tr>"
        for label, val in rows
    )

    return f"""
    <div style="overflow-x:auto">
      <table style="border-collapse:collapse;width:100%;font-family:sans-serif;
                    font-size:14px;border:1px solid #e0e0e0;border-radius:8px;overflow:hidden">
        <thead>
          <tr style="background:#f5f7fa">
            <th style="padding:10px 14px;text-align:left;font-size:15px;
                       border-bottom:2px solid #ddd" colspan="2">
              Head-to-Head Statistical Summary
            </th>
          </tr>
        </thead>
        <tbody>{trs}</tbody>
      </table>
    </div>"""


def build_delta_plot(
    boot_a: pd.DataFrame,
    boot_b: pd.DataFrame,
    display_name_a: str,
    display_name_b: str,
    track: str,
) -> go.Figure:
    """Build the bootstrap delta distribution histogram."""
    metric = TRACK_PRIMARY_METRIC.get(track.lower(), "MAE")
    lower_better = metric.upper() in {m.upper() for m in LOWER_IS_BETTER}

    merged = boot_a[["Sample", metric]].merge(
        boot_b[["Sample", metric]], on="Sample", suffixes=("_a", "_b")
    )
    delta = merged[f"{metric}_a"] - merged[f"{metric}_b"]

    n = len(delta)
    n_a_wins = int((delta < 0).sum() if lower_better else (delta > 0).sum())
    n_b_wins = int((delta > 0).sum() if lower_better else (delta < 0).sum())

    tooltip = (
        f"<b>{display_name_a}</b> won {n_a_wins}/{n} bootstrap samples<br>"
        f"<b>{display_name_b}</b> won {n_b_wins}/{n} bootstrap samples"
    )

    delta_range = float(delta.max() - delta.min())
    bin_size = delta_range / 50 if delta_range > 0 else 0.01

    fig = go.Figure()
    fig.add_trace(
        go.Histogram(
            x=delta[delta > 0],
            name=f"Δ > 0 ({display_name_a} higher {metric})",
            marker_color=COLOR_POS_DELTA,
            opacity=0.80,
            hovertemplate=tooltip + "<extra></extra>",
            xbins=dict(size=bin_size),
        )
    )
    fig.add_trace(
        go.Histogram(
            x=delta[delta < 0],
            name=f"Δ < 0 ({display_name_b} higher {metric})",
            marker_color=COLOR_NEG_DELTA,
            opacity=0.80,
            hovertemplate=tooltip + "<extra></extra>",
            xbins=dict(size=bin_size),
        )
    )
    fig.add_vline(
        x=0,
        line_dash="dot",
        line_color="#333",
        line_width=2,
        annotation_text="Δ = 0",
        annotation_position="top right",
        annotation_font_size=11,
    )
    fig.update_layout(
        title=dict(
            text=f"Bootstrap Δ ({display_name_a} − {display_name_b}): {metric}",
            font_size=15,
        ),
        xaxis_title=f"Δ {metric} (A − B)",
        yaxis_title="Bootstrap Samples",
        barmode="overlay",
        legend=dict(orientation="h", y=-0.18),
        margin=dict(l=50, r=20, t=60, b=80),
        plot_bgcolor="white",
        paper_bgcolor="white",
        bargap=0.02,
        transition=dict(duration=600, easing="cubic-in-out"),
    )
    fig.update_xaxes(showgrid=True, gridcolor="#eeeeee", zeroline=False)
    fig.update_yaxes(showgrid=True, gridcolor="#eeeeee")
    return fig


def build_activity_scatter(
    pred_a: pd.DataFrame,
    pred_b: pd.DataFrame,
    display_name_a: str,
    display_name_b: str,
    endpoint: str,
) -> go.Figure:
    """Scatter of molecules ordered by ground truth ``endpoint`` with user predictions."""
    identifiers = DATA_CACHE.get("activity_identifiers", pd.DataFrame())
    gt_all = DATA_CACHE.get("activity_dataset", pd.DataFrame())

    if identifiers.empty or gt_all.empty:
        return go.Figure()

    phase2_mols = set(
        identifiers.loc[identifiers["phase"] == ACTIVITY_TARGET_PHASE, "Molecule_Name"]
    )
    gt = gt_all[gt_all["Molecule_Name"].isin(phase2_mols)].reset_index(drop=True)

    base = gt[["Molecule_Name", endpoint]].rename(columns={endpoint: "GT_value"})
    pa = pred_a[["Molecule_Name", endpoint]].rename(columns={endpoint: "A_value"})
    pb = pred_b[["Molecule_Name", endpoint]].rename(columns={endpoint: "B_value"})

    df = (
        base.merge(pa, on="Molecule_Name", how="left")
        .merge(pb, on="Molecule_Name", how="left")
        .sort_values("GT_value")
        .reset_index(drop=True)
    )
    df["x_rank"] = range(len(df))

    mk = dict(size=6, opacity=0.8)
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=df["x_rank"],
            y=df["GT_value"],
            mode="markers",
            name="Ground Truth",
            marker=dict(**mk, color=COLOR_GT, symbol="circle"),
            text=df["Molecule_Name"],
            hovertemplate=f"<b>%{{text}}</b><br>ground truth {endpoint}: %{{y:.3f}}<extra></extra>",
        )
    )
    fig.add_trace(
        go.Scatter(
            x=df["x_rank"],
            y=df["A_value"],
            mode="markers",
            name=display_name_a,
            marker=dict(**mk, color=COLOR_USER_A, symbol="diamond"),
            text=df["Molecule_Name"],
            hovertemplate=(
                "<b>%{text}</b><br>"
                + display_name_a
                + f" {endpoint}: %{{y:.3f}}<extra></extra>"
            ),
        )
    )
    fig.add_trace(
        go.Scatter(
            x=df["x_rank"],
            y=df["B_value"],
            mode="markers",
            name=display_name_b,
            marker=dict(**mk, color=COLOR_USER_B, symbol="cross"),
            text=df["Molecule_Name"],
            hovertemplate=(
                "<b>%{text}</b><br>"
                + display_name_b
                + f" {endpoint}: %{{y:.3f}}<extra></extra>"
            ),
        )
    )
    fig.update_layout(
        title=dict(
            text=f"Phase {ACTIVITY_TARGET_PHASE} — {endpoint} Predictions vs Ground Truth",
            font_size=15,
        ),
        xaxis=dict(
            title=f"Compounds ordered by ground truth {endpoint} (ascending)",
            showticklabels=False,
            showgrid=False,
        ),
        yaxis=dict(title=endpoint, showgrid=True, gridcolor="#eeeeee"),
        legend=dict(orientation="h", y=-0.12),
        margin=dict(l=60, r=20, t=60, b=100),
        plot_bgcolor="white",
        paper_bgcolor="white",
        hovermode="closest",
    )
    return fig


def build_structure_bar(
    per_compound_a: pd.DataFrame,
    per_compound_b: pd.DataFrame,
    display_name_a: str,
    display_name_b: str,
) -> go.Figure:
    """Show grouped bar chart of per-compound LDDT-PLI for both users.

    Compound order follows the structure-identifiers file so the x-axis is
    consistent across comparisons.
    """
    metric = "LDDT-PLI"
    identifiers = DATA_CACHE.get("structure_identifiers", pd.DataFrame())

    per_compound_a = per_compound_a.rename(columns={"Molecule_Name": "Molecule_Name"})
    per_compound_b = per_compound_b.rename(columns={"Molecule_Name": "Molecule_Name"})
    df_a = per_compound_a.set_index("Molecule_Name")[[metric]].rename(
        columns={metric: "A_score"}
    )
    df_b = per_compound_b.set_index("Molecule_Name")[[metric]].rename(
        columns={metric: "B_score"}
    )
    df = df_a.join(df_b, how="outer")

    if not identifiers.empty and "Molecule_Name" in identifiers.columns:
        ordered = [m for m in identifiers["Molecule_Name"] if m in df.index]
        df = df.reindex(ordered)

    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            x=df.index,
            y=df["A_score"],
            name=display_name_a,
            marker_color=COLOR_USER_A,
            opacity=0.85,
            hovertemplate=(
                "<b>%{x}</b><br>"
                + display_name_a
                + " LDDT-PLI: %{y:.3f}<extra></extra>"
            ),
        )
    )
    fig.add_trace(
        go.Bar(
            x=df.index,
            y=df["B_score"],
            name=display_name_b,
            marker_color=COLOR_USER_B,
            opacity=0.85,
            hovertemplate=(
                "<b>%{x}</b><br>"
                + display_name_b
                + " LDDT-PLI: %{y:.3f}<extra></extra>"
            ),
        )
    )
    fig.update_layout(
        title=dict(
            text="Per-Compound LDDT-PLI — All 184 Compounds",
            font_size=15,
        ),
        xaxis=dict(
            title="Compounds (ordered by identifier)",
            showticklabels=False,
            showgrid=False,
        ),
        yaxis=dict(
            title="LDDT-PLI",
            showgrid=True,
            gridcolor="#eeeeee",
            range=[0, 1],
        ),
        barmode="group",
        bargap=0.05,
        bargroupgap=0.02,
        legend=dict(orientation="h", y=-0.14),
        margin=dict(l=60, r=20, t=80, b=80),
        plot_bgcolor="white",
        paper_bgcolor="white",
        hovermode="closest",
    )

    # Add phase boundary line if the identifiers file has a phase column
    if not identifiers.empty and "phase" in identifiers.columns:
        ident_idx = identifiers.set_index("Molecule_Name").reindex(df.index)
        phases = ident_idx["phase"].tolist()
        phase1_positions = [i for i, p in enumerate(phases) if p == 1]
        if phase1_positions:
            boundary = phase1_positions[-1] + 0.5
            n_total = len(df)
            fig.add_shape(
                type="line",
                x0=boundary,
                x1=boundary,
                y0=0,
                y1=1,
                xref="x",
                yref="paper",
                line=dict(dash="dot", color="#555", width=2),
            )
            fig.add_annotation(
                x=boundary / 2,
                y=1.07,
                xref="x",
                yref="paper",
                text="Used for live leaderboard",
                showarrow=False,
                xanchor="center",
                font=dict(size=11, color="#555"),
            )
            fig.add_annotation(
                x=(boundary + n_total) / 2,
                y=1.07,
                xref="x",
                yref="paper",
                text="Remaining test set",
                showarrow=False,
                xanchor="center",
                font=dict(size=11, color="#555"),
            )

    return fig


# ==============================================================================
# 5. INTERFACE RENDERER & LOGIC
# ==============================================================================


def render_comparisons():
    """Render the Gradio interface for head-to-head comparisons."""
    global DATA_CACHE
    DATA_CACHE = download_necessary_files()

    gr.Markdown("Choose a challenge track and two participants to compare.")
    with gr.Row():
        track_dd = gr.Dropdown(
            choices=["Activity", "Structure"],
            value=None,
            label="Track",
            scale=1,
        )
        user_a_dd = gr.Dropdown(
            choices=[], value=None, label="User A", scale=2, interactive=True
        )
        user_b_dd = gr.Dropdown(
            choices=[], value=None, label="User B", scale=2, interactive=True
        )

    with gr.Row():
        submit_btn = gr.Button(
            "🥊 Compare Entries", variant="primary", scale=1, interactive=False
        )

    status_md = gr.Markdown(visible=False)

    with gr.Row(visible=False) as top_row_layout:
        with gr.Column(scale=1):
            gr.Markdown("### Head-to-Head Statistics")
            stats_output = gr.HTML("")
        with gr.Column(scale=1):
            gr.Markdown("### Delta Distribution Plot")
            delta_plot = gr.Plot()

    with gr.Row(visible=False) as bottom_row_layout:
        with gr.Column(scale=1, visible=False) as activity_mol_column:
            gr.Markdown("### Per-Compound Comparison (by endpoint)")
            activity_mol_plots: dict[str, gr.Plot] = {}
            with gr.Tabs():
                for endpoint in ACTIVITY_ENDPOINTS:
                    with gr.TabItem(endpoint):
                        activity_mol_plots[endpoint] = gr.Plot()
        with gr.Column(scale=1, visible=False) as structure_mol_column:
            gr.Markdown("### Per-Compound Comparison")
            structure_mol_plot = gr.Plot()

    _all_outputs = [
        status_md,
        top_row_layout,
        bottom_row_layout,
        stats_output,
        delta_plot,
        activity_mol_column,
        structure_mol_column,
        *[activity_mol_plots[endpoint] for endpoint in ACTIVITY_ENDPOINTS],
        structure_mol_plot,
    ]

    # 1. Track change: update User A choices, clear User B
    track_dd.change(
        fn=handle_track_change,
        inputs=[track_dd],
        outputs=[user_a_dd, user_b_dd],
    ).then(
        fn=reset_analysis_outputs,
        inputs=None,
        outputs=_all_outputs,
    )

    # 2. User A selection: update User B choices (excluding A)
    user_a_dd.change(
        fn=update_user_b_choices,
        inputs=[track_dd, user_a_dd],
        outputs=[user_b_dd],
    )

    # 3. Enable submit button only when all three selections are populated
    gr.on(
        triggers=[track_dd.change, user_a_dd.change, user_b_dd.change],
        fn=validate_submission_controls,
        inputs=[track_dd, user_a_dd, user_b_dd],
        outputs=[submit_btn],
    )

    # 4. Submit: run full comparison and populate all outputs.
    submit_btn.click(
        fn=run_comparison,
        inputs=[track_dd, user_a_dd, user_b_dd],
        outputs=_all_outputs,
    )

    # 5. Any dropdown change resets the outputs to hidden
    gr.on(
        triggers=[track_dd.change, user_a_dd.change, user_b_dd.change],
        fn=reset_analysis_outputs,
        inputs=None,
        outputs=_all_outputs,
    )


def handle_track_change(track):
    """Update after selection of Track."""
    choices = list_leaderboard_entries(track)
    return gr.update(choices=choices, value=None), gr.update(choices=[], value=None)


def update_user_b_choices(track: str, user_a_selection: str):
    """Update after selection of User A."""
    if not track or not user_a_selection:
        return gr.update(choices=[], value=None)
    choices = list_leaderboard_entries(track)
    filtered_choices = [entry for entry in choices if entry != user_a_selection]
    return gr.update(choices=filtered_choices, value=None)


def validate_submission_controls(track, user_a, user_b):
    """Enable the submit button only if all three dropdowns have selections."""
    is_valid = bool(track and user_a and user_b)
    return gr.update(interactive=is_valid)


def _cleared_outputs() -> tuple:
    """Return the full _all_outputs tuple in its hidden/empty state."""
    return (
        gr.update(visible=False, value=""),  # status_md
        gr.update(visible=False),  # top_row_layout
        gr.update(visible=False),  # bottom_row_layout
        gr.update(value=""),  # stats_output
        gr.update(value=go.Figure()),  # delta_plot
        gr.update(visible=False),  # activity_mol_column
        gr.update(visible=False),  # structure_mol_column
        *[gr.update(value=go.Figure()) for _ in ACTIVITY_ENDPOINTS],  # activity plots
        gr.update(value=go.Figure()),  # structure_mol_plot
    )


def reset_analysis_outputs():
    """Hide all chart rows and status messages when a dropdown value changes."""
    return _cleared_outputs()


def run_comparison(track: str, user_a: str, user_b: str):
    """Load data for the selected users and build all comparison charts."""
    logger.info(f"Running comparison: Track={track}, User A={user_a}, User B={user_b}")

    if not track or not user_a or not user_b:
        cleared = list(_cleared_outputs())
        cleared[0] = gr.update(
            value="⚠️ **Error:** Please select Track, User A, and User B.",
            visible=True,
        )
        yield tuple(cleared)
        return

    yield _cleared_outputs()  # clear while loading

    try:
        user_a_rank = int(user_a.split(".")[0]) - 1
        user_b_rank = int(user_b.split(".")[0]) - 1

        display_name_a = _get_display_name(track, user_a_rank)
        display_name_b = _get_display_name(track, user_b_rank)
        hf_username_a = _get_hf_username(track, user_a_rank)
        hf_username_b = _get_hf_username(track, user_b_rank)

        pw_row = _get_pairwise_row(track, hf_username_a, hf_username_b)
        boot_a = _load_bootstrap(track, user_a_rank)
        boot_b = _load_bootstrap(track, user_b_rank)

        stats_html = build_stats_table(
            track, display_name_a, display_name_b, boot_a, boot_b, pw_row
        )
        delta_fig = build_delta_plot(
            boot_a, boot_b, display_name_a, display_name_b, track
        )

        if track.lower() == "activity":
            pred_a = _load_activity_predictions(user_a_rank)
            pred_b = _load_activity_predictions(user_b_rank)
            activity_plot_updates = [
                gr.update(
                    value=build_activity_scatter(
                        pred_a, pred_b, display_name_a, display_name_b, endpoint
                    )
                )
                for endpoint in ACTIVITY_ENDPOINTS
            ]
            structure_plot_update = gr.update()
            activity_col_update = gr.update(visible=True)
            structure_col_update = gr.update(visible=False)
        else:
            per_a = _load_structure_per_compound(user_a_rank)
            per_b = _load_structure_per_compound(user_b_rank)
            structure_plot_update = gr.update(
                value=build_structure_bar(per_a, per_b, display_name_a, display_name_b)
            )
            activity_plot_updates = [gr.update() for _ in ACTIVITY_ENDPOINTS]
            activity_col_update = gr.update(visible=False)
            structure_col_update = gr.update(visible=True)

        status_msg = (
            f"## Showing analysis for {display_name_a} vs {display_name_b} "
            f"({track} Track)"
        )

        yield (
            gr.update(value=status_msg, visible=True),  # status_md
            gr.update(visible=True),  # top_row_layout
            gr.update(visible=True),  # bottom_row_layout
            gr.update(value=stats_html),  # stats_output
            gr.update(value=delta_fig),  # delta_plot
            activity_col_update,  # activity_mol_column
            structure_col_update,  # structure_mol_column
            *activity_plot_updates,
            structure_plot_update,
        )

    except Exception as e:
        logger.exception(f"Error in run_comparison: {e}")
        cleared = list(_cleared_outputs())
        cleared[0] = gr.update(value=f"⚠️ **Error:** {e}", visible=True)
        yield tuple(cleared)
